"""
Open-World ROC, AUC, and TPR@FPR Evaluation for WF Attacks
USING DEFENDED OPEN-WORLD TRACES (LTRAC)
"""

import os
import numpy as np
import torch
import joblib
import matplotlib.pyplot as plt

from sklearn.metrics import roc_curve, roc_auc_score

# ==== Import WFlib attacks ====
from wflib.attack import DF, TikTok, VarCNN

# --------------------
# Config / paths
# --------------------
x_mon_defended_path = " data//X_test_defended.npy"
y_mon_path = " data//y_test.npy"
x_unmon_defended_path = "data//X_ow_defended.npy"

model_dir = "wflib/attack/models"
batch_size = 256
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

out_dir = "./ow_roc_defended"
os.makedirs(out_dir, exist_ok=True)

# --------------------
# Utility functions
# --------------------
def normalize_unit_max(X):
    X = X.astype(np.float32, copy=False)
    m = np.max(X)
    return X / m if m > 0 else X

def ensure_varcnn_channels(X):
    if X.ndim == 2:
        X = np.stack([X, X], axis=1)
    elif X.ndim == 3 and X.shape[1] == 1:
        X = np.repeat(X, 2, axis=1)
    return X

@torch.no_grad()
def infer_scores_nn(model, X, device, batch_size):
    model.eval().to(device)
    softmax = torch.nn.Softmax(dim=1)
    scores = []

    for i in range(0, len(X), batch_size):
        xb = X[i:i+batch_size].to(device)
        logits = model(xb)
        prob = softmax(logits)
        scores.append(prob.max(dim=1).values.cpu().numpy())

    return np.concatenate(scores)

def compute_ow_metrics(y_true, y_score):
    fpr, tpr, _ = roc_curve(y_true, y_score)
    auc = roc_auc_score(y_true, y_score)

    def tpr_at(alpha):
        idx = np.where(fpr <= alpha)[0]
        return tpr[idx[-1]] if len(idx) else 0.0

    return {
        "auc": auc,
        "tpr@0.1%": tpr_at(0.001),
        "tpr@1%": tpr_at(0.01),
        "fpr": fpr,
        "tpr": tpr
    }

def plot_roc(metrics, name):
    plt.figure()
    plt.plot(metrics["fpr"] * 100, metrics["tpr"] * 100,
             label=f"AUC={metrics['auc']:.3f}", linewidth=2)
    plt.xlim(0, 5)
    plt.ylim(0, 100)
    plt.xlabel("False Positive Rate (%)")
    plt.ylabel("True Positive Rate (%)")
    plt.grid(alpha=0.3)
    plt.legend()
    plt.title(name)
    plt.savefig(os.path.join(out_dir, f"{name}_ROC.png"),
                dpi=300, bbox_inches="tight")
    plt.close()

# --------------------
# Load defended data
# --------------------
print("Loading defended traces...")
x_mon = normalize_unit_max(np.load(x_mon_defended_path))
x_unm = normalize_unit_max(np.load(x_unmon_defended_path))
y_mon = np.load(y_mon_path)

print("Monitored:", x_mon.shape)
print("Unmonitored:", x_unm.shape)

# Labels
y_true = np.concatenate([
    np.ones(len(x_mon), dtype=int),
    np.zeros(len(x_unm), dtype=int)
])

results = {}

# --------------------
# DF / TikTok
# --------------------
def eval_df_tiktok(name, cls, model_file):
    def to_1ch(X):
        return X[:, None, :] if X.ndim == 2 else X

    Xm = torch.tensor(to_1ch(x_mon))
    Xu = torch.tensor(to_1ch(x_unm))

    model = cls(num_classes=int(y_mon.max()) + 1)
    model.load_state_dict(torch.load(model_file, map_location=device))

    s_mon = infer_scores_nn(model, Xm, device, batch_size)
    s_unm = infer_scores_nn(model, Xu, device, batch_size)

    scores = np.concatenate([s_mon, s_unm])
    metrics = compute_ow_metrics(y_true, scores)

    plot_roc(metrics, name)
    return metrics

results["DF"] = eval_df_tiktok("DF", DF, os.path.join(model_dir, "DF.pth"))
results["TikTok"] = eval_df_tiktok("TikTok", TikTok, os.path.join(model_dir, "TikTok.pth"))

# --------------------
# Var-CNN
# --------------------
Xm = torch.tensor(ensure_varcnn_channels(x_mon))
Xu = torch.tensor(ensure_varcnn_channels(x_unm))

model = VarCNN(num_classes=int(y_mon.max()) + 1)
model.load_state_dict(torch.load(os.path.join(model_dir, "VarCNN.pth"),
                                 map_location=device))

s_mon = infer_scores_nn(model, Xm, device, batch_size)
s_unm = infer_scores_nn(model, Xu, device, batch_size)

scores = np.concatenate([s_mon, s_unm])
results["VarCNN"] = compute_ow_metrics(y_true, scores)
plot_roc(results["VarCNN"], "VarCNN")

# --------------------
# Random Forest
# --------------------
rf_obj = joblib.load(os.path.join(model_dir, "RF.pkl"))
rf, scaler = rf_obj if isinstance(rf_obj, tuple) else (rf_obj, None)

Xm = x_mon.reshape(len(x_mon), -1)
Xu = x_unm.reshape(len(x_unm), -1)

if scaler is not None:
    Xm = scaler.transform(Xm)
    Xu = scaler.transform(Xu)

p_mon = rf.predict_proba(Xm).max(axis=1)
p_unm = rf.predict_proba(Xu).max(axis=1)

scores = np.concatenate([p_mon, p_unm])
results["RF"] = compute_ow_metrics(y_true, scores)
plot_roc(results["RF"], "RF")

# --------------------
# Save paper-ready summary
# --------------------
with open(os.path.join(out_dir, "ow_metrics_summary.txt"), "w") as f:
    f.write("Open-World Metrics (Defended Traces)\n")
    f.write("Attack | AUC | TPR@0.1% | TPR@1%\n")
    f.write("-" * 40 + "\n")
    for k, v in results.items():
        f.write(f"{k:7s} | {v['auc']:.4f} | {v['tpr@0.1%']:.4f} | {v['tpr@1%']:.4f}\n")

print("\n=== FINAL OPEN-WORLD RESULTS ===")
for k, v in results.items():
    print(f"{k}: AUC={v['auc']:.4f}, "
          f"TPR@0.1%={v['tpr@0.1%']:.4f}, "
          f"TPR@1%={v['tpr@1%']:.4f}")
