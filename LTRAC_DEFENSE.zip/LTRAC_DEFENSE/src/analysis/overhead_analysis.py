#!/usr/bin/env python
# coding: utf-8

# In[ ]:


#BANDWITH AND TIMWE OVERHEAD
import numpy as np

# Load your trace files
x_orig = np.load("data/X_test.npy")
x_def = np.load("data/X_test_defended.npy")

print(f"Original shape: {x_orig.shape}")
print(f"Defended shape: {x_def.shape}")

# === Bandwidth Overhead ===
# Bandwidth = total number of bursts (non-zero entries)
orig_bandwidth = np.count_nonzero(x_orig, axis=1)
def_bandwidth = np.count_nonzero(x_def, axis=1)

bandwidth_overhead = np.mean(def_bandwidth / (orig_bandwidth + 1e-8))
bandwidth_percent = (bandwidth_overhead - 1) * 100

# === Time Overhead ===
# Time = index of last non-zero burst
orig_time = np.max(np.where(x_orig != 0, np.arange(x_orig.shape[1]), 0), axis=1)
def_time = np.max(np.where(x_def != 0, np.arange(x_def.shape[1]), 0), axis=1)

time_overhead = np.mean(def_time / (orig_time + 1e-8))
time_percent = (time_overhead - 1) * 100

# === Print Results ===
print("\n=== Your Defense Overhead ===")
print(f"Bandwidth Overhead: {bandwidth_overhead:.3f}x ({bandwidth_percent:.2f}%)")
print(f"Time Overhead     : {time_overhead:.3f}x ({time_percent:.2f}%)")

# === Palette Comparison ===
palette_bandwidth_overhead = 1.84   # Palette has 84% bandwidth overhead
palette_time_overhead = 1.09        # Palette has 9% time overhead

print("\n--- Comparison to Palette ---")
if bandwidth_overhead < palette_bandwidth_overhead:
    print(f"✓ Bandwidth Overhead Improved vs Palette ({bandwidth_overhead:.2f}x < 1.84x)")
else:
    print(f"✗ Bandwidth Overhead Higher than Palette ({bandwidth_overhead:.2f}x > 1.84x)")

if time_overhead < palette_time_overhead:
    print(f"✓ Time Overhead Improved vs Palette ({time_overhead:.2f}x < 1.09x)")
else:
    print(f"✗ Time Overhead Higher than Palette ({time_overhead:.2f}x > 1.09x)")

