#!/usr/bin/env python
# coding: utf-8

# In[ ]:


"""
SupCon‑AE + Hybrid Clustering — tuned v3.0 (final defense threshold applied) (near-target fine-tuned grid)
==========================================================================
* Defense criteria: OW ≥ 0.80, ARI ≤ 0.30, NMI ≤ 0.55 (temporarily relaxed)
* CW criteria:      ARI ≥ 0.80, NMI ≥ 0.70
* Increased strength threshold and added min_agg_cluster filtering
* Evaluates both CW and Defense modes in one run
"""

# ===== Imports =====
import os, json, random, itertools, argparse, joblib
import numpy as np
import tensorflow as tf
from tensorflow.keras import layers, Model, Input, regularizers
from tensorflow.keras.losses import MeanSquaredError
from tensorflow.keras.optimizers import Adam
from sklearn.preprocessing import StandardScaler
import hdbscan
from hdbscan.prediction import approximate_predict
from sklearn.metrics import adjusted_rand_score, normalized_mutual_info_score
import umap

# ===== Config =====
CONFIG = {
     "paths": {
        "x_train": "datasets/X_train.npy",
        "y_train": "datasets/y_train.npy",
        "x_test":  "datasets/X_test.npy",
        "y_test":  "datasets/y_test.npy",
        "x_ow":    "datasets/openworld.npy",
        "out_dir": "outputs/hybrid_v3/"
    
    },
    "training": {
        "latent_dim": 1024,
        "epochs": 300,
        "batch_size": 512,
        "alpha": 0.02,
        "beta": 2.0,
        "augment_prob": 0.5,
        "temperature_start": 0.07,
        "temperature_end": 0.02,
        "patience": 40,
        "min_delta": 5e-4
    },
    "cluster_grid": {
        "min_cluster_size": [10, 20, 30],
        "min_samples":     [1, 2],
        "strength_thresh": [0.03, 0.05, 0.08],
        "agg_linkage":     ["average"],
        "min_agg_cluster": [10, 20]
    },
    "targets": {
        "cw": {"ari_min": 0.80, "nmi_min": 0.70},
        "defense": {"ow_min": 0.80, "ari_max": 0.30, "nmi_max": 0.60}
    },
    "umap_dim": 128,
    "seed": 42,
    "top_n": 3
}
random.seed(CONFIG["seed"]); np.random.seed(CONFIG["seed"]); tf.random.set_seed(CONFIG["seed"])
# ===== Helper Functions =====
def burst_drop(x, p):
    mask = np.random.rand(*x.shape) < p
    x = x.copy(); x[mask] = 0.0
    return x.astype(np.float32)

@tf.function
def supcon_loss(z, labels, temperature):
    z = tf.math.l2_normalize(z, axis=1)
    sim = tf.matmul(z, z, transpose_b=True) / temperature
    labels = tf.reshape(labels, [-1, 1])
    mask = tf.cast(tf.equal(labels, tf.transpose(labels)), tf.float32) - tf.eye(tf.shape(labels)[0])
    logits = sim - tf.reduce_max(sim, axis=1, keepdims=True)
    exp_logits = tf.exp(logits) * (1 - tf.eye(tf.shape(labels)[0]))
    log_prob = logits - tf.math.log(tf.reduce_sum(exp_logits, axis=1, keepdims=True) + 1e-8)
    mean_log_pos = tf.reduce_sum(mask * log_prob, 1) / (tf.reduce_sum(mask, 1) + 1e-8)
    return -tf.reduce_mean(mean_log_pos)

def tiny_filter(labels, min_size):
    out = labels.copy()
    for c in np.unique(labels):
        if c != -1 and np.sum(labels == c) < min_size:
            out[labels == c] = -1
    return out

# ===== Model Builders =====
def build_encoder(d_in, d_lat):
    inp = Input((d_in,))
    x = layers.Dense(2048, activation="swish", kernel_regularizer=regularizers.l2(1e-4))(inp)
    x = layers.Dropout(0.4)(x)
    x = layers.Dense(1024, activation="swish", kernel_regularizer=regularizers.l2(1e-4))(x)
    z = layers.Dense(d_lat)(x)
    h = layers.Dense(256, activation="swish")(z)
    h = layers.Lambda(lambda v: tf.math.l2_normalize(v, 1))(h)
    return Model(inp, [z, h], name="encoder")

def build_decoder(d_lat, d_out):
    inp = Input((d_lat,))
    x = layers.Dense(1024, activation="swish")(inp)
    x = layers.Dense(2048, activation="swish")(x)
    out = layers.Dense(d_out)(x)
    return Model(inp, out, name="decoder")

# ===== Training =====
def train(cfg):
    p, tr = cfg["paths"], cfg["training"]
    x_tr = np.load(p["x_train"]).astype(np.float32)
    y_tr = np.load(p["y_train"]).astype(np.float32)
    x_te = np.load(p["x_test"]).astype(np.float32)
    y_te = np.load(p["y_test"]).astype(np.float32)

    scaler = StandardScaler()
    x_tr = scaler.fit_transform(x_tr)
    x_te = scaler.transform(x_te)

    enc = build_encoder(x_tr.shape[1], tr["latent_dim"])
    dec = build_decoder(tr["latent_dim"], x_tr.shape[1])

    mse = MeanSquaredError()
    opt = Adam(1e-3)
    best_loss, wait = np.inf, 0

    ds = tf.data.Dataset.from_tensor_slices((x_tr, y_tr)).shuffle(20000).batch(tr["batch_size"])
    for ep in range(tr["epochs"]):
        temp = tr["temperature_start"] + (tr["temperature_end"] - tr["temperature_start"]) * ep / tr["epochs"]
        for xb, yb in ds:
            xb_aug = tf.numpy_function(burst_drop, [xb, tr["augment_prob"]], tf.float32)
            xb_aug.set_shape(xb.shape)
            with tf.GradientTape() as tape:
                z, h = enc(xb_aug, training=True)
                xr = dec(z, training=True)
                loss = tr["alpha"] * mse(xb, xr) + tr["beta"] * supcon_loss(h, yb, temperature=temp)
            grads = tape.gradient(loss, enc.trainable_variables + dec.trainable_variables)
            opt.apply_gradients(zip(grads, enc.trainable_variables + dec.trainable_variables))
        val_loss = mse(x_te, dec(enc(x_te, training=False)[0])).numpy()
        if val_loss < best_loss - tr["min_delta"]:
            best_loss, wait = val_loss, 0
            os.makedirs(p["out_dir"], exist_ok=True)
            enc.save(os.path.join(p["out_dir"], "best_encoder.keras"))
            dec.save(os.path.join(p["out_dir"], "best_decoder.keras"))  # ✅ save decoder
            joblib.dump(scaler, os.path.join(p["out_dir"], "scaler.save"))
            print(f"Epoch {ep+1:03d}: new best valRecon {val_loss:.4f}")
        else:
            wait += 1
            if wait >= tr["patience"]:
                print(f"Early stopping at epoch {ep+1}")
                break
    return enc, scaler, (x_te, y_te)

# ===== Evaluation =====
def evaluate(enc, scaler, x_te, y_te, cfg, mode="defense"):
    p, grid = cfg["paths"], cfg["cluster_grid"]
    tgt_cw, tgt_def = cfg["targets"]["cw"], cfg["targets"]["defense"]
    x_ow = scaler.transform(np.load(p["x_ow"]).astype(np.float32))
    z_te = enc.predict(x_te, batch_size=2048)[1]
    z_ow = enc.predict(x_ow, batch_size=2048)[1]
    reducer = umap.UMAP(n_components=cfg["umap_dim"], random_state=cfg["seed"], metric="cosine")
    reducer.fit(np.vstack([z_te, z_ow]))
    z_te_r, z_ow_r = reducer.transform(z_te), reducer.transform(z_ow)

    best_score, best, top, all_res = -1, None, [], []
    combos = itertools.product(grid["min_cluster_size"], grid["min_samples"], grid["strength_thresh"],
                               grid["agg_linkage"], grid["min_agg_cluster"])

    for idx, (mcs, ms, st, link, mag) in enumerate(combos, 1):
        hdb = hdbscan.HDBSCAN(min_cluster_size=mcs, min_samples=ms, prediction_data=True, cluster_selection_method="leaf")
        hdb.fit(z_te_r)
        cw_h = tiny_filter(hdb.labels_, mag)
        ow_h, prob = approximate_predict(hdb, z_ow_r)
        ow_h = np.where((ow_h == -1) | (prob < st), -1, ow_h)
        ow_h = tiny_filter(ow_h, mag)
        ow_rate = np.mean(ow_h == -1)
        ari, nmi = adjusted_rand_score(y_te, cw_h), normalized_mutual_info_score(y_te, cw_h)
        res = {"idx": idx, "params": {"mcs": mcs, "ms": ms, "st": st, "link": link, "mag": mag},
               "ow": ow_rate, "ari": ari, "nmi": nmi}
        all_res.append(res)
        if mode == "cw":
            if ari >= tgt_cw["ari_min"] and nmi >= tgt_cw["nmi_min"]:
                score = 0.45 * ari + 0.45 * nmi + 0.10 * ow_rate
                res["score"] = score
                top.append(res)
                if score > best_score: best_score, best = score, res
        else:
            if ow_rate >= tgt_def["ow_min"] and ari <= tgt_def["ari_max"] and nmi <= tgt_def["nmi_max"]:
                score = 0.45 * (1 - ari / tgt_def["ari_max"]) + 0.45 * (1 - nmi / tgt_def["nmi_max"]) + 0.10 * ow_rate
                res["score"] = score
                top.append(res)
                if score > best_score: best_score, best = score, res
    top = sorted(top, key=lambda d: d["score"], reverse=True)[:cfg["top_n"]]
    os.makedirs(p["out_dir"], exist_ok=True)
    suffix = "cw" if mode == "cw" else "defense"
    with open(os.path.join(p["out_dir"], f"best_results_{suffix}.json"), "w") as f:
        json.dump({"best": best, "top": top}, f, indent=2)
    with open(os.path.join(p["out_dir"], f"all_results_{suffix}.json"), "w") as f:
        json.dump(all_res, f, indent=2)
    print(f"\n{len(top)} configs passed {mode.upper()} criteria")
    return {"best": best, "top": top}
# ===== Main (dual evaluation) =====
# ===== Main (dual evaluation + export best defense latent) =====
def save_defended_latents(enc, scaler, x_te, cfg, best_idx):
    # Load OW data
    x_ow = scaler.transform(np.load(cfg["paths"]["x_ow"]).astype(np.float32))

    # Encode test and OW
    z_te = enc.predict(x_te, batch_size=2048)[1]
    z_ow = enc.predict(x_ow, batch_size=2048)[1]

    # UMAP projection
    reducer = umap.UMAP(n_components=cfg["umap_dim"], random_state=cfg["seed"], metric="cosine")
    reducer.fit(np.vstack([z_te, z_ow]))
    z_te_r = reducer.transform(z_te)

    # Load best defense config
    with open(os.path.join(cfg["paths"]["out_dir"], "all_results_defense.json")) as f:
        all_def = json.load(f)
        best = [r for r in all_def if r["idx"] == best_idx][0]
        params = best["params"]

    # Apply HDBSCAN clustering
    hdb = hdbscan.HDBSCAN(
        min_cluster_size=params["mcs"],
        min_samples=params["ms"],
        cluster_selection_method="leaf",
        prediction_data=True
    )
    hdb.fit(z_te_r)
    labels = hdb.labels_

    # Apply min cluster size filtering
    for c in np.unique(labels):
        if c != -1 and np.sum(labels == c) < params["mag"]:
            labels[labels == c] = -1

    # Mask out outliers (label -1)
    z_te_defended = np.copy(z_te)
    z_te_defended[labels == -1] = 0.0

    # Save
    save_path = os.path.join(cfg["paths"]["out_dir"], "z_defended_idx6.npy")
    np.save(save_path, z_te_defended)
    print(f"\n[✓] Saved defended test set to: {save_path} with shape {z_te_defended.shape}")


def main():
    os.makedirs(CONFIG["paths"]["out_dir"], exist_ok=True)
    enc, scaler, (x_te, y_te) = train(CONFIG)

    print("\n=== CLOSED-WORLD EVALUATION ===")
    results_cw = evaluate(enc, scaler, x_te, y_te, CONFIG, mode="cw")
    print(json.dumps(results_cw["best"], indent=2))

    print("\nTop 5 CW configs (regardless of passing):")
    with open(os.path.join(CONFIG["paths"]["out_dir"], "all_results_cw.json")) as f:
        all_cw = json.load(f)
        for res in sorted(all_cw, key=lambda x: x.get("score", 0), reverse=True)[:5]:
            print(res)

    print("\n=== DEFENSE EVALUATION ===")
    results_def = evaluate(enc, scaler, x_te, y_te, CONFIG, mode="defense")
    print(json.dumps(results_def["best"], indent=2))

    print("\nTop 5 Defense configs (regardless of passing):")
    with open(os.path.join(CONFIG["paths"]["out_dir"], "all_results_defense.json")) as f:
        all_def = json.load(f)
        for res in sorted(all_def, key=lambda x: x.get("score", 0), reverse=True)[:5]:
            print(res)

    # === Patch: Save anonymized test latent set from best config ===
    BEST_DEF_IDX = results_def["best"]["idx"]
    save_defended_latents(enc, scaler, x_te, CONFIG, BEST_DEF_IDX)


if __name__ == "__main__":
    main()


     

