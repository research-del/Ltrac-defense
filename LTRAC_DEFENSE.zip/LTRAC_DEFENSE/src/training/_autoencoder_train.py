#!/usr/bin/env python
# coding: utf-8

# In[18]:


# train_encoders.py

import os
import pickle
import numpy as np
from sklearn.preprocessing import MinMaxScaler
from tensorflow.keras import layers, models, callbacks

# ------------ Utility Functions ------------

def load_pickle(file_path):
    with open(file_path, 'rb') as f:
        return pickle.load(f,encoding='latin1')

def save_pickle(data, file_path):
    with open(file_path, 'wb') as f:
        pickle.dump(data, f)

def normalize_data(X_train, X_test):
    scaler = MinMaxScaler()
    X_train_norm = scaler.fit_transform(X_train)
    X_test_norm = scaler.transform(X_test)
    return X_train_norm, X_test_norm, scaler

# ------------ Autoencoder Architecture ------------

def build_autoencoder(input_dim, latent_dim=64):
    input_layer = layers.Input(shape=(input_dim,))
    x = layers.Dense(512, activation='relu')(input_layer)
    x = layers.Dense(256, activation='relu')(x)
    x = layers.Dense(128, activation='relu')(x)
    latent = layers.Dense(latent_dim, activation='relu', name='latent')(x)

    x = layers.Dense(128, activation='relu')(latent)
    x = layers.Dense(256, activation='relu')(x)
    x = layers.Dense(512, activation='relu')(x)
    output_layer = layers.Dense(input_dim, activation='sigmoid')(x)

    autoencoder = models.Model(input_layer, output_layer)
    encoder = models.Model(input_layer, latent)
    autoencoder.compile(optimizer='adam', loss='mse')

    return autoencoder, encoder

# ------------ Training Pipeline ------------

def train_autoencoder_on_dataset(X_train, X_test, scenario_name, output_dir='outputs', latent_dim=64):
    print(f"Training Autoencoder for {scenario_name}...")

    os.makedirs(output_dir, exist_ok=True)

    X_train_norm, X_test_norm, scaler = normalize_data(X_train, X_test)
    input_dim = X_train.shape[1]

    autoencoder, encoder = build_autoencoder(input_dim, latent_dim)

    autoencoder.fit(
        X_train_norm, X_train_norm,
        validation_data=(X_test_norm, X_test_norm),
        epochs=50,
        batch_size=256,
        shuffle=True,
        callbacks=[callbacks.EarlyStopping(monitor='val_loss', patience=5, restore_best_weights=True)]
    )

    # Encode and save
    X_train_encoded = encoder.predict(X_train_norm)
    X_test_encoded = encoder.predict(X_test_norm)

    save_pickle(X_train_encoded, f'{output_dir}/X_train_encoded_{scenario_name}.pkl')
    save_pickle(X_test_encoded, f'{output_dir}/X_test_encoded_{scenario_name}.pkl')
    encoder.save(f'{output_dir}/encoder_{scenario_name}.h5')
    autoencoder.save(f'{output_dir}/autoencoder_{scenario_name}.h5')

    print(f"[✓] {scenario_name} training done. Encoded data and models saved.")

# ------------ Main Execution ------------

if __name__ == "__main__":
   # Set your actual dataset folder path here
    closed_dir = r'C:\Users\andrews\Desktop\df\closeworld'
    open_dir = r'C:\Users\andrews\Desktop\df\openworld'
    output_dir = r'C:\Users\andrews\Desktop\df_outputs'

# Load datasets
print("Loading datasets...")
X_train_NoDef = np.array(load_pickle(f'{closed_dir}/X_train_NoDef.pkl'))
X_test_NoDef =  np.array(load_pickle(f'{closed_dir}/X_test_NoDef.pkl'))
y_train_NoDef = load_pickle(f'{closed_dir}/y_train_NoDef.pkl')
y_test_NoDef = load_pickle(f'{closed_dir}/y_test_NoDef.pkl')

# Optional: Load labels (if available and needed)
X_train_NoDefopen =  np.array(load_pickle(f'{open_dir}/X_train_NoDefopen.pkl'))
X_test_Unmon_NoDef =  np.array(load_pickle(f'{open_dir}/X_test_Unmon_NoDef.pkl'))
y_train_NoDefopen = load_pickle(f'{open_dir}/y_train_NoDefopen.pkl')
y_test_Unmon_NoDef = load_pickle(f'{open_dir}/y_test_Unmon_NoDef.pkl')



# Train both scenarios
train_autoencoder_on_dataset(X_train_NoDef, X_test_NoDef, 'closeworld', output_dir=output_dir)
train_autoencoder_on_dataset(X_train_NoDefopen, X_test_Unmon_NoDef, 'openworld', output_dir=output_dir)
 
 


# In[ ]:




