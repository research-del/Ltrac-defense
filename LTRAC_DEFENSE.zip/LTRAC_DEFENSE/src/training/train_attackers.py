#!/usr/bin/env python
# coding: utf-8

# In[ ]:


# Training attackers and saving weights for later evaluation
import os
import numpy as np
import torch
import torch.nn as nn
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import StandardScaler
import joblib

from wflib.attack.DF import DF
from wflib.attack.TikTok import TikTok
from wflib.attack.VarCNN import VarCNN

# Paths
x_train_path = "data/x_train.npy"
y_train_path = "data/y_train.npy"
x_test_defended_path = "data/x_test_defended.npy"
model_dir = "wflib/attack/models"
os.makedirs(model_dir, exist_ok=True)

# Load training data
X = np.load(x_train_path)
y = np.load(y_train_path)

# ---------- Train Random Forest ----------
print("\nTraining Random Forest...")
scaler = StandardScaler()
X_flat = X.reshape((X.shape[0], -1))
X_scaled = scaler.fit_transform(X_flat)

rf = RandomForestClassifier(n_estimators=200, max_depth=50, n_jobs=-1)
rf.fit(X_scaled, y)
joblib.dump((rf, scaler), os.path.join(model_dir, "RF.pkl"))
print("Saved: RF.pkl")

# ---------- Convert to PyTorch ----------
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
X_tensor = torch.tensor(X, dtype=torch.float32).to(device)
y_tensor = torch.tensor(y, dtype=torch.long).to(device)
if X_tensor.ndim == 2:
    X_tensor = X_tensor.unsqueeze(1)

num_classes = int(y_tensor.max().item()) + 1
epochs = 10
batch_size = 128
criterion = nn.CrossEntropyLoss()

# ---------- Train DF ----------
print("\nTraining DF...")
df = DF(num_classes=num_classes).to(device)
optimizer = torch.optim.Adam(df.parameters(), lr=1e-3)
for epoch in range(epochs):
    df.train()
    perm = torch.randperm(X_tensor.size(0))
    for i in range(0, X_tensor.size(0), batch_size):
        idx = perm[i:i+batch_size]
        out = df(X_tensor[idx])
        loss = criterion(out, y_tensor[idx])
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
    print(f"[DF] Epoch {epoch+1}/{epochs}, Loss: {loss.item():.4f}")
torch.save(df.state_dict(), os.path.join(model_dir, "DF.pth"))
print("Saved: DF.pth")

# ---------- Train TikTok ----------
print("\nTraining TikTok...")
tiktok = TikTok(num_classes=num_classes).to(device)
optimizer = torch.optim.Adam(tiktok.parameters(), lr=1e-3)
for epoch in range(epochs):
    tiktok.train()
    perm = torch.randperm(X_tensor.size(0))
    for i in range(0, X_tensor.size(0), batch_size):
        idx = perm[i:i+batch_size]
        out = tiktok(X_tensor[idx])
        loss = criterion(out, y_tensor[idx])
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
    print(f"[TikTok] Epoch {epoch+1}/{epochs}, Loss: {loss.item():.4f}")
torch.save(tiktok.state_dict(), os.path.join(model_dir, "TikTok.pth"))
print("Saved: TikTok.pth")

# ---------- Train VarCNN (requires 2x5000 input) ----------
print("\nTraining VarCNN...")
X_defended = np.load(x_test_defended_path)
if X_defended.ndim != 2:
    raise ValueError(f"x_test_defended.npy must be 2D, but got shape {X_defended.shape}")

target_len = 5000
N, L = X_defended.shape
if L < target_len:
    X_padded = np.pad(X_defended, ((0, 0), (0, target_len - L)))
else:
    X_padded = X_defended[:, :target_len]

X_varcnn = np.stack([X_padded, X_padded], axis=1)  # (N, 2, 5000)
X_varcnn_tensor = torch.tensor(X_varcnn, dtype=torch.float32).to(device)

varcnn = VarCNN(num_classes=num_classes).to(device)
optimizer = torch.optim.Adam(varcnn.parameters(), lr=1e-3)
for epoch in range(epochs):
    varcnn.train()
    perm = torch.randperm(X_varcnn_tensor.size(0))
    for i in range(0, X_varcnn_tensor.size(0), batch_size):
        idx = perm[i:i+batch_size]
        out = varcnn(X_varcnn_tensor[idx])
        loss = criterion(out, y_tensor[idx])
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
    print(f"[VarCNN] Epoch {epoch+1}/{epochs}, Loss: {loss.item():.4f}")
torch.save(varcnn.state_dict(), os.path.join(model_dir, "VarCNN.pth"))
print("Saved: VarCNN.pth")

print("\n✅ All attackers trained and saved successfully.")

