#!/usr/bin/env python
# coding: utf-8

# In[ ]:


"""
SupCon-AE + CW Clustering Evaluation (CW‑only version)
=======================================================
This script trains SupCon-AE on closed-world traffic
and evaluates clustering quality only in CW mode.

Output:
- best_results_cw.json
- all_results_cw.json
- encoder + scaler
"""

import os, json, random, itertools, joblib
import numpy as np
import tensorflow as tf
from tensorflow.keras import layers, Model, Input, regularizers
from tensorflow.keras.losses import MeanSquaredError
from tensorflow.keras.optimizers import Adam
from sklearn.preprocessing import StandardScaler
import hdbscan
from sklearn.metrics import adjusted_rand_score, normalized_mutual_info_score
import umap

CONFIG = {
    "paths": {
        "./data/X_train.npy"
"./data/y_train.npy"
"./data/X_test.npy"
"./data/y_test.npy"
"./outputs/supcon_cw"

        "out_dir": r"C:/outputs/supcon_cw"
    },
    "training": {
        "latent_dim": 1024,
        "epochs": 300,
        "batch_size": 512,
        "alpha": 0.05,
        "beta": 2.0,
        "augment_prob": 0.3,
        "temperature_start": 0.1,
        "temperature_end": 0.03,
        "patience": 30,
        "min_delta": 1e-3 
    },
    "cluster_grid": {
       "min_cluster_size": [5, 10, 20, 30, 40, 50],
        "min_samples":     [1, 2, 5],
        "agg_linkage":     ["average"],
        "min_agg_cluster": [0]
    },
    "targets": {
        "cw": {"ari_min": 0.80, "nmi_min": 0.70}
    },
    "umap_dim": 64,
    "seed": 42,
    "top_n": 3
}
random.seed(CONFIG["seed"]); np.random.seed(CONFIG["seed"]); tf.random.set_seed(CONFIG["seed"])

def burst_drop(x, p):
    mask = np.random.rand(*x.shape) < p
    x = x.copy(); x[mask] = 0.0
    return x.astype(np.float32)

@tf.function
def supcon_loss(z, labels, temperature):
    z = tf.math.l2_normalize(z, axis=1)
    sim = tf.matmul(z, z, transpose_b=True) / temperature
    labels = tf.reshape(labels, [-1, 1])
    mask = tf.cast(tf.equal(labels, tf.transpose(labels)), tf.float32) - tf.eye(tf.shape(labels)[0])
    logits = sim - tf.reduce_max(sim, axis=1, keepdims=True)
    exp_logits = tf.exp(logits) * (1 - tf.eye(tf.shape(labels)[0]))
    log_prob = logits - tf.math.log(tf.reduce_sum(exp_logits, axis=1, keepdims=True) + 1e-8)
    mean_log_pos = tf.reduce_sum(mask * log_prob, 1) / (tf.reduce_sum(mask, 1) + 1e-8)
    return -tf.reduce_mean(mean_log_pos)

def tiny_filter(labels, min_size):
    out = labels.copy()
    for c in np.unique(labels):
        if c != -1 and np.sum(labels == c) < min_size:
            out[labels == c] = -1
    return out

def build_encoder(d_in, d_lat):
    inp = Input((d_in,))
    x = layers.Dense(2048, activation="swish", kernel_regularizer=regularizers.l2(1e-4))(inp)
    x = layers.Dropout(0.3)(x)
    x = layers.Dense(1024, activation="swish", kernel_regularizer=regularizers.l2(1e-4))(x)
    z = layers.Dense(d_lat)(x)
    h = layers.Dense(256, activation="swish")(z)
    h = layers.Lambda(lambda v: tf.math.l2_normalize(v, 1))(h)
    return Model(inp, [z, h], name="encoder")

def build_decoder(d_lat, d_out):
    inp = Input((d_lat,))
    x = layers.Dense(1024, activation="swish")(inp)
    x = layers.Dense(2048, activation="swish")(x)
    out = layers.Dense(d_out)(x)
    return Model(inp, out, name="decoder")

def train(cfg):
    p, tr = cfg["paths"], cfg["training"]
    x_tr = np.load(p["x_train"]).astype(np.float32)
    y_tr = np.load(p["y_train"]).astype(np.float32)
    x_te = np.load(p["x_test"]).astype(np.float32)
    y_te = np.load(p["y_test"]).astype(np.float32)

    scaler = StandardScaler()
    x_tr = scaler.fit_transform(x_tr)
    x_te = scaler.transform(x_te)

    enc = build_encoder(x_tr.shape[1], tr["latent_dim"])
    dec = build_decoder(tr["latent_dim"], x_tr.shape[1])

    mse = MeanSquaredError()
    opt = Adam(1e-3)
    best_loss, wait = np.inf, 0

    ds = tf.data.Dataset.from_tensor_slices((x_tr, y_tr)).shuffle(20000).batch(tr["batch_size"])
    for ep in range(tr["epochs"]):
        temp = tr["temperature_start"] + (tr["temperature_end"] - tr["temperature_start"]) * ep / tr["epochs"]
        for xb, yb in ds:
            xb_aug = tf.numpy_function(burst_drop, [xb, tr["augment_prob"]], tf.float32)
            xb_aug.set_shape(xb.shape)
            with tf.GradientTape() as tape:
                z, h = enc(xb_aug, training=True)
                xr = dec(z, training=True)
                loss = tr["alpha"] * mse(xb, xr) + tr["beta"] * supcon_loss(h, yb, temperature=temp)
            grads = tape.gradient(loss, enc.trainable_variables + dec.trainable_variables)
            opt.apply_gradients(zip(grads, enc.trainable_variables + dec.trainable_variables))
        val_loss = mse(x_te, dec(enc(x_te, training=False)[0])).numpy()
        if val_loss < best_loss - tr["min_delta"]:
            best_loss, wait = val_loss, 0
            os.makedirs(p["out_dir"], exist_ok=True)
            enc.save(os.path.join(p["out_dir"], "best_encoder.keras"))
            joblib.dump(scaler, os.path.join(p["out_dir"], "scaler.save"))
            print(f"Epoch {ep+1:03d}: new best valRecon {val_loss:.4f}")
        else:
            wait += 1
            if wait >= tr["patience"]:
                print(f"Early stopping at epoch {ep+1}")
                break
    return enc, scaler, (x_te, y_te)

def evaluate(enc, scaler, x_te, y_te, cfg):
    p, grid, tgt = cfg["paths"], cfg["cluster_grid"], cfg["targets"]["cw"]
    z_te = enc.predict(x_te, batch_size=2048)[1]
    reducer = umap.UMAP(n_components=cfg["umap_dim"], random_state=cfg["seed"], metric="cosine")
    z_te_r = reducer.fit_transform(z_te)

    best_score, best, top, all_res = -1, None, [], []
    combos = itertools.product(grid["min_cluster_size"], grid["min_samples"], grid["agg_linkage"], grid["min_agg_cluster"])

    for idx, (mcs, ms, link, mag) in enumerate(combos, 1):
        hdb = hdbscan.HDBSCAN(min_cluster_size=mcs, min_samples=ms, prediction_data=False, cluster_selection_method="leaf")
        hdb.fit(z_te_r)
        cw_h = tiny_filter(hdb.labels_, mag)
        ari = adjusted_rand_score(y_te, cw_h)
        nmi = normalized_mutual_info_score(y_te, cw_h)
        res = {"idx": idx, "params": {"mcs": mcs, "ms": ms, "link": link, "mag": mag}, "ari": ari, "nmi": nmi}
        all_res.append(res)
        if ari >= tgt["ari_min"] and nmi >= tgt["nmi_min"]:
            score = 0.5 * ari + 0.5 * nmi
            res["score"] = score
            top.append(res)
            if score > best_score:
                best_score, best = score, res

    top = sorted(top, key=lambda d: d.get("score", 0), reverse=True)[:cfg["top_n"]]
    os.makedirs(p["out_dir"], exist_ok=True)
    with open(os.path.join(p["out_dir"], "best_results_cw.json"), "w") as f:
        json.dump({"best": best, "top": top}, f, indent=2)
    with open(os.path.join(p["out_dir"], "all_results_cw.json"), "w") as f:
        json.dump(all_res, f, indent=2)

    print(f"\n{len(top)} configs passed CW criteria")
    print(json.dumps(best, indent=2))

if __name__ == "__main__":
    encoder, scaler, (x_te, y_te) = train(CONFIG)
    evaluate(encoder, scaler, x_te, y_te, CONFIG)

