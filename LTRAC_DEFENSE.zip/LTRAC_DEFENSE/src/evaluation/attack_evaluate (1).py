#!/usr/bin/env python
# coding: utf-8

# In[ ]:


import numpy as np
import torch
import joblib
from sklearn.metrics import accuracy_score
from wflib.attack import DF, TikTok, VarCNN, RF
import json  # Added for saving results

# ==== CONFIGURATION ====
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model_dir = "wflib/attack/models"
x_test_path = "path/to/X_test_defended.npy"
y_test_path = "path/to/y_test.npy"
# ==== LOAD TEST DATA ====
X_test = np.load(x_test_path)  # Expected shape: [N, L] or [N, 1, L]
y_test = np.load(y_test_path)

print("Loaded test data:", X_test.shape, y_test.shape)

# ==== Normalize ====
X_test = X_test.astype(np.float32)
X_test /= np.max(X_test)

# ==== Convert Labels ====
y_true = torch.tensor(y_test).to(device)

# ==== Evaluate Function ====
def evaluate_model(model, model_path, X_tensor, batch_size=128):
    model.load_state_dict(torch.load(model_path, map_location=device))
    model.to(device).eval()

    all_preds = []
    with torch.no_grad():
        for i in range(0, X_tensor.shape[0], batch_size):
            x_batch = X_tensor[i:i + batch_size]
            y_pred = model(x_batch)
            pred_labels = torch.argmax(y_pred, dim=1)
            all_preds.append(pred_labels.cpu())

    all_preds = torch.cat(all_preds)
    acc = accuracy_score(y_true.cpu(), all_preds) * 100
    return acc


# ==== Test All Attackers ====
results = {}

print("\n[Evaluating Defended Test Set Accuracy]\n")

# 1. DF
df = DF(num_classes=int(y_test.max()) + 1)
X_df = torch.tensor(X_test).unsqueeze(1).to(device)  # [N, 1, L]
results["DF"] = evaluate_model(df, f"{model_dir}/DF.pth", X_df)
print(f"DF Accuracy:       {results['DF']:.2f}%")

# 2. TikTok
tiktok = TikTok(num_classes=int(y_test.max()) + 1)
X_tt = torch.tensor(X_test).unsqueeze(1).to(device)  # [N, 1, L]
results["TikTok"] = evaluate_model(tiktok, f"{model_dir}/TikTok.pth", X_tt)
print(f"TikTok Accuracy:   {results['TikTok']:.2f}%")

# 3. Var-CNN — requires at least 2 channels
varcnn = VarCNN(num_classes=int(y_test.max()) + 1)
if X_test.ndim == 2:
    # Expand to 2-channel fake version by duplicating direction and timing
    X_vcnn = np.stack([X_test, X_test], axis=1)  # [N, 2, L]
else:
    X_vcnn = X_test
X_vcnn = torch.tensor(X_vcnn).to(device)
results["VarCNN"] = evaluate_model(varcnn, f"{model_dir}/VarCNN.pth", X_vcnn)
print(f"Var-CNN Accuracy:  {results['VarCNN']:.2f}%")

# 4. Random Forest (PyTorch version)

# Load both model and scaler if saved as tuple
rf_model_path = f"{model_dir}/RF.pkl"
rf_model, rf_scaler = joblib.load(rf_model_path)

# Apply scaling to test data
X_test_scaled = rf_scaler.transform(X_test)

# Predict
y_pred_rf = rf_model.predict(X_test_scaled)

# Accuracy
rf_acc = accuracy_score(y_test, y_pred_rf) * 100
results["RF"] = rf_acc
print(f"Random Forest Accuracy: {rf_acc:.2f}%")

# ==== Summary ====
print("\n--- Defense Results vs Palette Baseline ---")
palette = {"DF": 20.27, "TikTok": 24.73, "VarCNN": 22.79, "RF": 36.43}
for atk in results:
    print(f"{atk:10s}: {results[atk]:5.2f}% (Palette: {palette.get(atk, 'N/A')}%)")

# ==== Save Results to JSON ====
with open("defense_results.json", "w") as json_file:
    json.dump(results, json_file, indent=4)

print("\n[✓] Results saved to defense_results.json")

